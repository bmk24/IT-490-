<?
echo "hello";

?>